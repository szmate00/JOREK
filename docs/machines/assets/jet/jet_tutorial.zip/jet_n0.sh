#!/bin/sh
#PBS -N jet_n0
#PBS -l walltime="40:00:00"

cd $PBS_O_WORKDIR
rm -f ${PBS_JOBNAME}.{out,err}
mpiexec -np $NUM_PROCS -pernode ~/jorek/jorek_model303_equil < in_jet_n0 >${PBS_JOBNAME}.out 2>${PBS_JOBNAME}.err

mv jorek2.ps jorek2_n0.ps
cp jorek_restart.rst jorek_n0.rst
