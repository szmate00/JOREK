#!/bin/sh

email="your@email.com"
export NUM_PROCS=8
export OMP_NUM_THREADS=16
export QUEUE=ib_gen8
common_args="-V -l nodes=$NUM_PROCS:ppn=$OMP_NUM_THREADS -q $QUEUE -m ae -M $email"

# Launch 2 simulations in order
EQUIL_JOB=`qsub jet_equil.sh $common_args`
echo "Submitted equilibrium job, id=$EQUIL_JOB"
N0_JOB=`qsub jet_n0.sh -W depend=afterok:$EQUIL_JOB $common_args`
echo "Submitted equilibrium n=0 job, id=$N0_JOB"
