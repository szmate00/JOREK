#!/bin/sh
#PBS -N jet_run
#PBS -l walltime="50:00:00"

cd $PBS_O_WORKDIR
rm -f ${PBS_JOBNAME}.{out,err}
mpiexec -np $NUM_PROCS -pernode ~/jorek/jorek_model303 < in_jet >${PBS_JOBNAME}.out 2>${PBS_JOBNAME}.err
