#!/bin/sh

email="your@email.com"
export NUM_PROCS=8
export OMP_NUM_THREADS=16
common_args="-V -l nodes=$NUM_PROCS:ppn=$OMP_NUM_THREADS -q ib_gen8 -m ae -M $email"

if [ $? -ge 1 ]; then
  qsub jet_run.sh -W depend=afterok:$1 $common_args
else
  qsub jet_run.sh $common_args
fi
