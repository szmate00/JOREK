#!/bin/sh
#PBS -N jet_equil
#PBS -l walltime="30:00:00"

cd $PBS_O_WORKDIR
rm -f ${PBS_JOBNAME}.{out,err}
mpiexec -np $NUM_PROCS -pernode ~/jorek/jorek_model303_equil < in_jet_equil >${PBS_JOBNAME}.out 2>${PBS_JOBNAME}.err

# Save output files
mv jorek2.ps jorek2_equil.ps
cp jorek_restart.rst jorek_equil.rst
